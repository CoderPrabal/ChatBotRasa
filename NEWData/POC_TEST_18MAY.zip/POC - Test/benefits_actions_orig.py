from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet

class ActionBenefit(Action):
	def name(self):
		return 'action_benefit'
		
	def run(self, dispatcher, tracker, domain):	
		
		loc = tracker.get_slot('service')
		
		response = """Our keyword is {} """.format(loc)
						
		dispatcher.utter_message(response)
		return [SlotSet('service',loc)]