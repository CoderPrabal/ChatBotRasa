from rasa_nlu.converters import load_data
from rasa_nlu.config import RasaNLUConfig
from rasa_nlu.model import Trainer
from rasa_core.agent import Agent
from keras.layers import LSTM, Activation, Masking, Dense
from keras.models import Sequential
"""
training_data = load_data('C:\\Users\\user\\Desktop\\rasa\\data\\greetings.json')
trainer = Trainer(RasaNLUConfig("C:\\Users\\user\\Desktop\\rasa\\nlu_model_config.json"))
trainer.train(training_data)
model_directory = trainer.persist('models/nlu/', fixed_model_name="greeting")

print(model_directory)
"""
def train_dialogue(domain_file="Domain.yml",
                   model_path="models/dialogue",
                   training_data_file="stories.md"):
    agent = Agent(domain_file,
                  policies=[MemoizationPolicy(), RestaurantPolicy()])

    agent.train(
            training_data_file,
            max_history=3,
            epochs=400,
            batch_size=100,
            validation_split=0.2
    )

    agent.persist(model_path)
    return agent

train_dialogue()