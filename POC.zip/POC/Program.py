from rasa_nlu.training_data import load_data
from rasa_nlu.config import RasaNLUModelConfig
from rasa_nlu.model import Trainer
from rasa_nlu import config


training_data = load_data('C:\\Users\\user\\Desktop\\rasa\\data\\testData.json')
trainer = Trainer(config.load("C:\\Users\\user\\Desktop\\rasa\\config_spacy.yml"))
trainer.train(training_data)
model_directory = trainer.persist('C:\\Users\\user\\Desktop\\rasa\\test')  # Returns the directory the model is stored in


from rasa_nlu.model import Metadata, Interpreter

# where `model_directory points to the folder the model is persisted in
interpreter = Interpreter.load(model_directory)
dictt = interpreter.parse(u"What are the benifits of my wheelchair?")    
print(dictt['intent_ranking'][0]['name'])   


"""
from rasa_nlu.converters import load_data
from rasa_nlu.config import RasaNLUConfig
from rasa_nlu.model import Trainer

training_data = load_data('C:\\Users\\user\\Desktop\\rasa\\data\\greetings.json')
trainer = Trainer(RasaNLUConfig("C:\\Users\\user\\Desktop\\rasa\\data\\nlu_model_config.json"))
trainer.train(training_data)
model_directory = trainer.persist('models/nlu/', fixed_model_name="greeting")

print(model_directory)"""
